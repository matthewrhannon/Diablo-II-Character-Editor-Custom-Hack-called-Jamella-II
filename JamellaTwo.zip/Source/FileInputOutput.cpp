//By Matt H.

#include "WorldWide.h"
#include "Character.h"
#include "FileInputOutput.h"
#include <time.h> //For time()

char RealPath[256];

CharacterProgression::CharacterProgression()
{


}

CharacterProgression::~CharacterProgression()
{
	if(CharacterData)
	{
		delete CharacterData;
		CharacterData = 0;
	}
}

char *CharacterProgression::CreateFileName(bool Open)
{
	OPENFILENAME ofn;

	ZeroMemory(&ofn,sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = MainhWnd;
	ofn.lpstrFilter = "D2S File (*.d2s)\0*.d2s\0";
	ofn.nFilterIndex = 0;
	ofn.lpstrFile = Buffer;
	ofn.nMaxFile = sizeof(Buffer);
	ofn.lpstrFileTitle = NULL;
	ofn.lpstrDefExt = "d2s";
	ofn.nMaxFileTitle = 0;
	ofn.Flags = 0;
	
	ZeroMemory(&Buffer, sizeof(Buffer));

	if(!Open)
		GetSaveFileName(&ofn);
	else
		GetOpenFileName(&ofn);

	return Buffer;
}

BYTE *CharacterProgression::ReloadCharacter()
{
	//Preliminary Checks already been done. IE. Excluded

	HANDLE hFile;

	hFile = CreateFile(RealPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if (hFile == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Couldnt Open the File you Selected!\nPossibly ReadOnly or Open?");
		return 0;
	}

	FileSize = GetFileSize(hFile, NULL);

	//File Size in bytes
	if(FileSize < 500)
	{
		MsgBoxError("File is too small!\n500 Bytes is tiny for a file like this!");
		CloseHandle(hFile);

		return 0;
	}
	if(FileSize > 15000)
	{
		MsgBoxError("The File is far to large!\n 15,000 BYTES is far too large for a file like this!");
		CloseHandle(hFile);
		
		return 0;
	}

	CharacterData = new BYTE[FileSize];

	ReadFile(hFile, CharacterData, FileSize, &FileReadSize, NULL);

	if(FileReadSize != FileSize)
	{
		MsgBoxError("Couldnt Read the Whole File!\nIt might be open or read only");

		delete CharacterData;
		CloseHandle(hFile);

		return 0;
	}

	CloseHandle(hFile);

	return CharacterData;
}

BYTE *CharacterProgression::GetFileInformation()
{
	FilePath = CreateFileName(true);
	strcpy(RealPath, FilePath);

	if(!strlen(FilePath))
	{
		MsgBoxError("You didnt select a file!");
		return 0;
	}

	if(!strstr(strupr(FilePath), ".D2S"))
	{
		MsgBox("The File you tried to load doesnt have the .d2s extension!");
		return 0;
	}

	char TempPath[256], Temp[256], Temp1[256];
	strcpy(TempPath, "");

	unsigned int Number = 0;

	while(Number < strlen(FilePath))
	{
		if(FilePath[strlen(FilePath) - Number] == '\\')
			break;
		else
		{
			sprintf(Temp, "%c", FilePath[strlen(FilePath) - Number]);
			
			//Quick little fix for printing the string backwards
			strcpy(Temp1, TempPath);
			strcpy(TempPath, Temp);
			strcat(TempPath, Temp1);
			
			Number++;
			continue;
		}
	}

	TempPath[strlen(TempPath) - 4] = '\0';

	strcpy(FileName, TempPath);
	
	HANDLE hFile;

	hFile = CreateFile(RealPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if (hFile == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Couldnt Open the File you Selected!\nPossibly ReadOnly or Open?");
		return 0;
	}

	FileSize = GetFileSize(hFile, NULL);

	//File Size in bytes
	if(FileSize < 500)
	{
		MsgBoxError("File is too small!\n500 Bytes is tiny for a file like this!");
		CloseHandle(hFile);

		return 0;
	}
	if(FileSize > 1500000)
	{
		MsgBoxError("The File is far to large!\n 15,000 BYTES is far too large for a file like this!");
		CloseHandle(hFile);
		
		return 0;
	}

	CharacterData = new BYTE[FileSize];

	ReadFile(hFile, CharacterData, FileSize, &FileReadSize, NULL);

	if(FileReadSize != FileSize)
	{
		MsgBoxError("Couldnt Read the Whole File!\nIt might be open or read only");

		delete CharacterData;
		CloseHandle(hFile);

		return 0;
	}

	CloseHandle(hFile);

	return CharacterData;
}

int CharacterProgression::WriteFileInformation()
{
	HANDLE hFile = CreateFile(RealPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if(hFile == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Could not create the file to save!\nIt maybe read only or open!");
		return 0;
	}

	DWORD Written;

	WriteFile(hFile, &FileInfo.GetCharacterInfo(), sizeof(FileInfo.GetCharacterInfo()), &Written, NULL);
	if(Written != sizeof(FileInfo.GetCharacterInfo()))
	{
		MsgBoxError("Could not write all of character info to the file!");
		return 0;
	}
	WriteFile(hFile, &FileInfo.GetCharacterQuestHeader(), sizeof(FileInfo.GetCharacterQuestHeader()), &Written, NULL);
	if(Written != sizeof(FileInfo.GetCharacterQuestHeader()))
	{
		MsgBoxError("Could not write all of quest header info to the file!");
		return 0;
	}
	
	CharacterQuests *Quests = FileInfo.GetCharacterQuests();
	
	WriteFile(hFile, &Quests[0], sizeof(Quests[0]), &Written, NULL);
	if(Written != sizeof(Quests[0]))
	{
		MsgBoxError("Could not write all of quest info to the file!");
		return 0;
	}
	WriteFile(hFile, &Quests[1], sizeof(Quests[1]), &Written, NULL);
	if(Written != sizeof(Quests[1]))
	{
		MsgBoxError("Could not write all of quest info to the file!");
		return 0;
	}
	WriteFile(hFile, &Quests[2], sizeof(Quests[2]), &Written, NULL);
	if(Written != sizeof(Quests[2]))
	{
		MsgBoxError("Could not write all of quest info to the file!");
		return 0;
	}
	
	WriteFile(hFile, &FileInfo.GetCharacterWayPointHead(), sizeof(FileInfo.GetCharacterWayPointHead()), &Written, NULL);
	if(Written != sizeof(FileInfo.GetCharacterWayPointHead()))
	{
		MsgBoxError("Could not write all of waypoint header info to the file!");
		return 0;
	}
	
	CharacterWayPoints *WayPoints = FileInfo.GetCharacterWayPoints();

	WriteFile(hFile, &WayPoints[0], sizeof(WayPoints[0]), &Written, NULL);
	if(Written != sizeof(WayPoints[0]))
	{
		MsgBoxError("Could not write all of waypoint info to the file!");
		return 0;
	}
	WriteFile(hFile, &WayPoints[1], sizeof(WayPoints[1]), &Written, NULL);
	if(Written != sizeof(WayPoints[1]))
	{
		MsgBoxError("Could not write all of waypoint info to the file!");
		return 0;
	}
	WriteFile(hFile, &WayPoints[2], sizeof(WayPoints[2]), &Written, NULL);
	if(Written != sizeof(WayPoints[2]))
	{
		MsgBoxError("Could not write all of waypoint info to the file!");
		return 0;
	}

	WriteFile(hFile, &FileInfo.GetCharacterNpc(), sizeof(FileInfo.GetCharacterNpc()), &Written, NULL);
	if(Written != sizeof(FileInfo.GetCharacterNpc()))
	{
		MsgBoxError("Could not write all of npc info to the file!");
		return 0;
	}
	
	CharacterStats Stats = FileInfo.GetCharacterStats();

	//Construct stat bit fields
	{
		for(int x = 0; x<16; x++)
		{
			if(Stats1[x] != 0)
				Stats.StatBits |=  1<<x;
		}
		
		RealStats->LifeBase *= 256;
		RealStats->LifeCurrent *= 256;
		RealStats->ManaBase *= 256;
		RealStats->ManaCurrent *= 256;
		RealStats->StaminaBase *= 256;
		RealStats->StaminaCurrent *= 256;
	}


	WriteFile(hFile, &Stats, sizeof(Stats), &Written, NULL);
	if(Written != sizeof(Stats))
	{
		MsgBoxError("Could not write all of stats header info to the file!");
		return 0;
	}

	for(int x = 0; x<16; x++)
	{
		if(Stats.StatBits & 1<<x)
		{
			WriteFile(hFile, &Stats1[x], sizeof(Stats1[x]), &Written, NULL);
			
			if(Written != sizeof(Stats1[x]))
			{
				MsgBoxError("Could not write one of the stat values to the file!");
				return 0;
			}
		}
	}

	WriteFile(hFile, &FileInfo.GetCharacterSkills(), sizeof(FileInfo.GetCharacterSkills()), &Written, NULL);
	if(Written != sizeof(FileInfo.GetCharacterSkills()))
	{
		MsgBoxError("Could not write all of skill info to the file!");
		return 0;
	}

	WriteFile(hFile, &FileInfo.GetCharacterItems(), sizeof(FileInfo.GetCharacterItems()), &Written, NULL);
	if(Written != sizeof(FileInfo.GetCharacterItems()))
	{
		MsgBoxError("Could not write all of item head info to the file!");
		return 0;
	}

	WriteFile(hFile, RemainingData, DataSize, &Written, NULL);

	if(Written != DataSize)
	{
		MsgBoxError("Could not write all of remaining info to the file!");
		return 0;
	} 

	CloseHandle(hFile);

	//Read file now to calculate checksum and file size and time stamp

	hFile = CreateFile(RealPath, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if (hFile == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Could not open file to calculate values");
		return 0;
	}

	DWORD TempFileReadSize;

	long TempFileSize = GetFileSize(hFile, NULL);
	
	BYTE *TempCharacterData = new BYTE[TempFileSize];

	ReadFile(hFile, TempCharacterData, TempFileSize, &TempFileReadSize, NULL);

	if(TempFileReadSize != TempFileSize)
	{
		MsgBoxError("Could not read the whole value to calculate values!");

		if(TempCharacterData)
		{
			delete TempCharacterData;
			TempCharacterData = 0;
		}
		CloseHandle(hFile);

		return 0;
	}

	*((unsigned long*)(TempCharacterData+8)) = TempFileSize;
	*((unsigned long*)(TempCharacterData+48)) = time(NULL);
	*((unsigned long*)(TempCharacterData+12)) = CalculateChecksum(TempCharacterData, TempFileSize);

	CloseHandle(hFile);

	//Finally save the file data to the final file
	hFile = CreateFile(RealPath, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	
	if(hFile == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Could not create the file to save!\nIt maybe read only or open!");
		
		if(TempCharacterData)
		{
			delete TempCharacterData;
			TempCharacterData = 0;
		}
		
		return 0;
	}

	WriteFile(hFile, TempCharacterData, TempFileSize, &Written, NULL);
	if(Written != TempFileSize)
	{
		MsgBoxError("Could not write all of character data to the file!");
	
		if(TempCharacterData)
		{
			delete TempCharacterData;
			TempCharacterData = 0;
		}
		
		return 0;
	}

	CloseHandle(hFile);

	if(TempCharacterData)
	{
		delete TempCharacterData;
		TempCharacterData = 0;
	}

return 1;
}

char *CharacterProgression::ReturnFilePath()
{
	return RealPath;
}

char *CharacterProgression::ReturnFileName()
{
	return FileName;
}

DWORD CharacterProgression::ReturnFileSize()
{
	return FileSize;
}

DWORD CharacterProgression::ReturnReadFileSize()
{
	return FileReadSize;
}
