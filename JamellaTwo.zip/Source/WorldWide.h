#define _CRT_SECURE_NO_DEPRECATE 1

#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 1
//WorldWide.h By Matt H.

#include <windows.h>
#include <windowsx.h> //GetWindowInstance()

#include <math.h>
#include <string.h>

#include <stdio.h>

#include <commctrl.h>

#include "resource.h"

//Link common control library to program
#pragma comment(lib, "comctl32.lib")

#define DEBUG_PROGRAM 1
#define RELEASE_PROGRAM -555
#define TEST_PROGRAM 0

#define NAME "Jamella2 -- Diablo2 Character Editor"
#define VERSION "Beta 0.01"
#define VERSION_NAME "Ownage"

#define MAX_STATS 85691245l
#define MAX_CONSTITUTION 16777215l

#define MAX_STATS_TEXT "4294967295"
#define MAX_CONSTITUTION_TEXT "16777215"

#define inline __forceinline

#define MsgBox(Text) MessageBox(NULL, Text, NAME, MB_OK | MB_APPLMODAL)
#define MsgBoxError(Text) MessageBox(NULL, Text, NAME, MB_OK | MB_ICONSTOP | MB_APPLMODAL)

extern HWND MainhWnd;
extern char Buffer[256];
extern HINSTANCE MainInstance;

extern BYTE *RemainingData;
extern int DataSize;
extern HWND g_Quests;

char *MakeDecimal(int X);
void ErrorMessage();

extern bool CheckName(char *Name);
extern long CalculateChecksum(BYTE *Data, long FileSize);
extern long CalculateMaxGold(bool IfStashFalse);
extern long CalculateMaxGold1(bool IfStashFalse);

BOOL CALLBACK MainProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK StatsProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK WayPointsProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK QuestsProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam);
