//Made By Matt H.

#pragma once

#include "WorldWide.h"
#include "CharacterTables.h"
#include "FileInputOutput.h"

class CharacterInformation
{
	public:
		CharacterInformation();
		~CharacterInformation();

		//Internal data
		BYTE *GetFileData();
		BYTE *GetTempFileData()
		{
			return TempFileData;
		}
		int GetCharacterSize();

		//Load it in
		int LoadCharacter();
		int LoadCharacterData();

		int ReloadCharacter();

		//Save it
		int SaveCharacter();

		//Error checking for structures
		int CheckCharacterHeader(CharacterHeader &Character);
		int CheckCharacterQuests(CharacterQuestHeader &Character);
		int CheckCharacterWayPoints(CharacterWayPointHeader &Character);
		int CheckCharacterNPC(CharacterNPC &Character);
		int CheckCharacterStats(CharacterStats &Character);
		int CheckCharacterSkills(CharacterSkills &Character);
		int CheckCharacterItems(CharacterItems &Items);

		//Get Data for structures
		CharacterHeader GetCharacterInfo();
		
		CharacterQuestHeader GetCharacterQuestHeader();
		CharacterQuests *GetCharacterQuests();
	
		CharacterWayPointHeader GetCharacterWayPointHead();
		CharacterWayPoints *GetCharacterWayPoints();
		
		CharacterNPC GetCharacterNpc();
		CharacterStats GetCharacterStats();
		CharacterSkills GetCharacterSkills();
		CharacterItems GetCharacterItems();
		
		//Varible setting functions
		
		//If value not good, returns good value, else set it and return 0
		long SetConstitutionValue(unsigned long Value, int StatNumber, char *Text);
		long SetStatsValue(unsigned long Value, int StatNumber, bool Over);
		unsigned long SetCharacterGold(unsigned long Value, bool StashIfFalse);

		void SetHardcore(int Hardcore, HWND hWnd);
		void SetDied(int Died);	
		void SetClass(int Class);
		void SetDifficulty(int Difficulty, HWND hWnd);
		void SetStartingTown(int Town);

		//For this,st atus is a value subtracted by a constant to get a whole small number
		void SetCharacterStatus(int Status);
		void SetCharacterName(char *Name);

		void SetCharacterMainLevel(int Level) {CharacterInfo.CharacterLevel = Level;}

		//Debugging
		void TestData()
		{
			MsgBox("Level:");
			MsgBox(MakeDecimal(RealStats->Level));
			
			MsgBox("Progess:");
			MsgBox(MakeDecimal(CharacterInfo.ChracterProgress));
			
			MsgBox("Name:");
			MsgBox(CharacterInfo.CharacterName);
			
			MsgBox("Class:");
			MsgBox(MakeDecimal(CharacterInfo.CharacterClass));
			
			MsgBox("Hardcore:");
			MsgBox(MakeDecimal(CharacterInfo.HardCore));
			
			MsgBox("Died:");
			MsgBox(MakeDecimal(CharacterInfo.Died));
		}

	private:
		CharacterProgression FileProgression;		
		
		CharacterHeader CharacterInfo;
		
		CharacterQuestHeader CharacterQuestHead;
		CharacterQuests CharacterQuest[3];

		CharacterWayPointHeader CharacterWayPointHead;
		CharacterWayPoints CharacterWayPoint[3];
		
		CharacterNPC CharacterNpc;
		
		CharacterStats CharacterStat;	
		CharacterSkills CharacterSkill;

		CharacterItems Items;

		BYTE *TempFileData;
		BYTE *FileData;

		int FileSize;
};

extern CharacterInformation FileInfo;