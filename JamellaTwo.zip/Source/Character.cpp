//Made By Matt H.

#include "WorldWide.h"
#include "Character.h"
#include "MiscDataTables.h"

struct RealStats1 *RealStats = (struct RealStats1*)&Stats1[0];
long Stats1[16];

BYTE *RemainingData;
int DataSize;

char Compare[16];

long CalculateChecksum(BYTE *Data, long FileSize)
{
	long Checksum = 0;
	char OverFlow = 0;

	//Clear the old checksum for the data
   *((unsigned long*)(Data+12)) = 0;

   for(long x = 0; x < FileSize; x++)
   {
      Checksum <<= 1;

      Checksum += Data[x] + OverFlow;

      if (Checksum < 0)
         OverFlow = 1;
      else
         OverFlow = 0;
   }

return Checksum;
}

CharacterInformation::CharacterInformation()
{
	for(int x = 0; x<16; x++)
		Stats1[x] = 0l;
}

CharacterInformation::~CharacterInformation()
{
	if(FileData)
	{
		delete FileData;
		FileData = 0;
	}
	if(TempFileData)
	{
		delete TempFileData;
		TempFileData = 0;
	}
	if(RemainingData)
	{
		delete RemainingData;
		RemainingData = 0;
	}
}

int CharacterInformation::LoadCharacterData()
{
	TempFileData = FileData;

	memcpy(&CharacterInfo, TempFileData, sizeof(CharacterInfo));
	TempFileData += sizeof(CharacterInfo);
//	MsgBox(MakeDecimal(CharacterInfo.Yes));
	if(CheckCharacterHeader(CharacterInfo) != 1)
		return 0;

	memcpy(&CharacterQuestHead, TempFileData, sizeof(CharacterQuestHead));
	TempFileData += sizeof(CharacterQuestHead);
	
	if(CheckCharacterQuests(CharacterQuestHead) != 1)
		return 0;

	memcpy(&CharacterQuest, TempFileData, sizeof(CharacterQuest));
	TempFileData += sizeof(CharacterQuest);

	memcpy(&CharacterWayPointHead, TempFileData, sizeof(CharacterWayPointHead));
	TempFileData += sizeof(CharacterWayPointHead);
	
	if(CheckCharacterWayPoints(CharacterWayPointHead) != 1)
		return 0;

	memcpy(&CharacterWayPoint, TempFileData, sizeof(CharacterWayPoint));
	TempFileData += sizeof(CharacterWayPoint);

	memcpy(&CharacterNpc, TempFileData, sizeof(CharacterNpc));
	TempFileData += sizeof(CharacterNpc);

	if(CheckCharacterNPC(CharacterNpc) != 1)
		return 0;

	memcpy(&CharacterStat, TempFileData, sizeof(CharacterStat));
	TempFileData += sizeof(CharacterStat);

	for(int x = 0; x<16; x++)
		Stats1[x] = 0l;
	
	//Character Stats
	{
		for(int x = 0; x<16; x++)
		{
			if(CharacterStat.StatBits & 1<<x)
			{
				memcpy(&Stats1[x], TempFileData, sizeof(Stats1[x]));
				TempFileData += sizeof(Stats1[x]);
			}
		}
		
		RealStats->LifeBase /= 256;
		RealStats->LifeCurrent /= 256;
		RealStats->ManaBase /= 256;
		RealStats->ManaCurrent /= 256;
		RealStats->StaminaBase /= 256;
		RealStats->StaminaCurrent /= 256;
	}

	if(CheckCharacterStats(CharacterStat) != 1)
		return 0;

	memcpy(&CharacterSkill, TempFileData, sizeof(CharacterSkill));
	TempFileData += sizeof(CharacterSkill);

	if(CheckCharacterSkills(CharacterSkill) != 1)
		return 0;

	memcpy(&Items, TempFileData, sizeof(Items));
	TempFileData += sizeof(Items);

	if(CheckCharacterItems(Items) != 1)
		return 0;

	DataSize = FileData+FileSize-TempFileData;

	RemainingData = new BYTE[DataSize];

	memcpy(RemainingData,TempFileData,DataSize);
	TempFileData += DataSize;

	if((TempFileData-FileData) != FileSize)
	{
		MsgBoxError("Major error! Couldnt read the whole file.\n\nPlease load another character.");
		return 0;
	}
	
return 1;
}

int CharacterInformation::LoadCharacter()
{
	FileData = FileProgression.GetFileInformation();

	if(FileData == 0)
		return 0;

	FileSize = FileProgression.ReturnFileSize();

	int Result = LoadCharacterData();

	if(Result != 1)
		return 0;

return 1;
}

int CharacterInformation::ReloadCharacter()
{
	FileData = FileProgression.ReloadCharacter();

	if(FileData == 0)
		return 0;

	FileSize = FileProgression.ReturnFileSize();

	int Result = LoadCharacterData();

	if(Result != 1)
		return 0;

return 1;
}

int CharacterInformation::SaveCharacter()
{
	if(FileProgression.WriteFileInformation() != 1)
		return 0;

return 1;
}

BYTE *CharacterInformation::GetFileData()
{
	return FileData;
}

		
int CharacterInformation::GetCharacterSize()
{
	return FileSize;
}

int CharacterInformation::CheckCharacterHeader(CharacterHeader &CharacterHead)
{
	if(CharacterHead.FileTag != 0xAA55AA55)
	{
		MsgBoxError("The File Tag of the file loaded in doesnt match\nthe specified tag for a\nDiablo2 Character File!\n\nCan not load it!");
		return 0;
	}

	if(CharacterHead.FileSize != FileProgression.ReturnFileSize())
	{
		if(MessageBox(HWND_DESKTOP, "The actual size of the file\nand the file size read in by the data do not match!\n\nWould you like to fix it?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
			CharacterHead.FileSize = FileProgression.ReturnFileSize();
		else
			return 0;
	}
	
	if(CalculateChecksum(FileInfo.GetFileData(), CharacterHead.FileSize) != CharacterHead.FileCheckSum)
	{
		if(MessageBox(HWND_DESKTOP, "The checksum calculated and the checksum in the file do not match!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
			CharacterHead.FileCheckSum = CalculateChecksum(FileInfo.GetFileData(),CharacterHead.FileSize);
		else
			return 0;
	}

	if(CharacterHead.FileVersion != 92)
	{
		MsgBoxError("The Diablo2 File loaded in is not version 1.09 Expansion!\nThat is the only version this editor supports!\nIn time it willl also support 1.10 Expansion.\n\nLoad this file with Jamella 3.0 editor!");
		return 0;
	}

	if(!CheckName(CharacterHead.CharacterName))
		MsgBoxError("The name with the character is invalid!\n The editor will continue loading the file but please note:\nIn the game, it will not load this file!\n\nIn order to fix, the name must have A-Z or a-z and\n one of - or _ in the name but not the first\n or last character.");

	char TempName[16];

	strcpy(TempName, CharacterHead.CharacterName);

	if(strcmp(strupr(CharacterHead.CharacterName), strupr(FileProgression.ReturnFileName())) != 0)
	{
		if(MessageBox(HWND_DESKTOP, "The name of the file and the name of the character in the data do not match.\nThis will cause Diablo2 to not load your file.\nInorder to fix this, change the file name to that presented in the editor!\n\nContinue Loading?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDNO)
			return 0;
	}
	
	strcpy(CharacterHead.CharacterName, TempName);

	if(CharacterHead.Expansion == 0)
	{
		MsgBoxError("This character file is not a expansion file!\nThis editor only supports so far 1.09 Expansion characters!\nExiting now!");
		return 0;
	}

	if(CharacterHead.CharacterClass > 6)
	{
		if(MessageBox(HWND_DESKTOP, "The character class(Amazon, Sorceress, etc) read in is out of range!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
			CharacterHead.CharacterClass = 6;
		else
			return 0;
	}

	if(CharacterHead.CharacterLevel > 99)
	{
		if(MessageBox(HWND_DESKTOP, "The level read in is greater than the max 99!\n Would you like to continue loading it?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDNO)
			return 0;
	}

	//Error checking for difficulty data
	{
		int ErrorCheck = 0;

		if(CharacterHead.NormalActive) ErrorCheck++;
		if(CharacterHead.NightmareActive) ErrorCheck++;
		if(CharacterHead.HellActive) ErrorCheck++;

		if(ErrorCheck > 1)
		{
			if(MessageBox(HWND_DESKTOP, "There were errors while loading the difficulty for the character!\nIt seems one or more of the difficultys are on which isnt\n valid!\n\nAttempt the fix?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
			{
				CharacterHead.NormalActive = 1;
				CharacterHead.NormalActive = 1;

				CharacterHead.NightmareActive = 0;
				CharacterHead.NightmareChacterAct = 0;

				CharacterHead.HellActive = 0;
				CharacterHead.HellChacterAct = 0;
			}
			else
				return 0;
		}

		if(ErrorCheck = 0)
		{
			if(MessageBox(HWND_DESKTOP, "While loading in the difficulty data, it seems none of the difficultys are set.\nThis is very invalid! \n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
			{
				CharacterHead.NormalActive = 1;
				CharacterHead.NormalChacterAct = 1;
			}
			else
				return 0;
		}
	}

	/* Obsolete

		//These checks are pretty trival and i am not even sure if the game checks for them.
		//But here they are!
		if(!CharacterHead.NormalActive && CharacterHead.NormalChacterAct != 0)
		{
			if(MessageBox(HWND_DESKTOP, "While reading in the difficulty data, the difficulty wasnt selected but its data was there!\n\nWould you like to fix this error?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
				CharacterHead.NormalChacterAct = 0;
			else
				return 0;
		}
		
		if(!CharacterHead.NightmareActive && CharacterHead.NightmareChacterAct != 0)
		{
			if(MessageBox(HWND_DESKTOP, "While reading in the difficulty data, the difficulty wasnt selected but its data was there!\n\nWould you like to fix this error?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
				CharacterHead.NightmareChacterAct = 0;
			else
				return 0;
		}

		if(!CharacterHead.HellActive && CharacterHead.HellChacterAct != 0)
		{
			if(MessageBox(HWND_DESKTOP, "While reading in the difficulty data, the difficulty wasnt selected but its data was there!\n\nWould you like to fix this error?", NAME, MB_YESNO | MB_APPLMODAL| MB_ICONSTOP) == IDYES)
				CharacterHead.HellChacterAct = 0;
			else
				return 0;
		}
	}
	*/

	if(CharacterHead.MercenaryID = 0 && (CharacterHead.MercenaryAlive != 0 || CharacterHead.MercenaryAttributesActAndAct != 0 || CharacterHead.MercenaryExperience != 0 || CharacterHead.MercenaryName != 0))
	{
		if(MessageBox(HWND_DESKTOP, "While reading in the Mercenary data, there were errors in the way that\n it said you had no mercenary ever yet some of the mercenary stats are filled out!\n\nAttempt to correct?", NAME, MB_YESNO | MB_APPLMODAL) == IDYES)
		{
			CharacterHead.MercenaryAlive = 0;
			CharacterHead.MercenaryAttributesActAndAct = 0;
			CharacterHead.MercenaryExperience = 0;
			CharacterHead.MercenaryName = 0;
		}
		else
			return 0;
	}
	

	if(CharacterHead.ChracterProgress > 15)
	{
		if(MessageBox(HWND_DESKTOP, "The character progression is out of range!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL) == IDYES)
			CharacterHead.ChracterProgress = 15;
		else
			return 0;
	}

return 1;
}

int CharacterInformation::CheckCharacterQuests(CharacterQuestHeader &Character)
{
	strcpy(Compare, Character.Woo);
	
	Compare[4] = '\0';

	if(strcmp(Compare, "Woo!") != 0)
	{
		MsgBoxError("The quest header was not found!\nThis is a serious error.\nThe editor can not fix!\n\nExiting now");
		return 0;
	}

return 1;
}
		
int CharacterInformation::CheckCharacterWayPoints(CharacterWayPointHeader &Character)
{
	strcpy(Compare, Character.WS);
	
	Compare[2] = '\0';

	if(strcmp(Compare, "WS") != 0)
	{
		MsgBoxError("The waypoint header was not found!\nThis is a serious error.\nThe editor can not fix!\n\nExiting now");
		return 0;
	}

return 1;
}
		
int CharacterInformation::CheckCharacterNPC(CharacterNPC &Character)
{
	strcpy(Compare, Character.W4);
	
	Compare[2] = '\0';
	
	if(strcmp(Compare, "w4") != 0)
	{
		MsgBoxError("The NPC header was not found!\nThis is a serious error.\nThe editor can not fix!\n\nExiting now");
		return 0;
	}

return 1;
}

int CharacterInformation::CheckCharacterStats(CharacterStats &Character)
{
	strcpy(Compare, Character.GF);
	
	Compare[2] = '\0';
	
	if(!strstr(Compare, "gf"))
	{
		MsgBoxError("The stats header was not found!\nThis is a serious error.\nThe editor can not fix!\n\nExiting now");
		return 0;
	}

	if(RealStats->Level > 99)
	{
		if(MessageBox(HWND_DESKTOP, "The level is greater than 99!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->Level = 99;
		else
			return 0;
	}

	if(RealStats->Level != CharacterInfo.CharacterLevel)
	{
		if(MessageBox(HWND_DESKTOP, "The level in main section and the level later in the file do not match!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			CharacterInfo.CharacterLevel = (char)RealStats->Level;
		else
			return 0;
	}
	
	if((unsigned)RealStats->Experience > ExperienceLevels[99])
	{
		if(MessageBox(HWND_DESKTOP, "The experience read in is greater than the maxium in the game!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->Experience = ExperienceLevels[99];
		else
			return 0;
	}

	long TempGold = CalculateMaxGold(true);

	if(TempGold != 0)
	{
		if(MessageBox(HWND_DESKTOP, "The program calculated the max gold availible for your character,\nand it determined your character's gold is greater\nthan the max amount. \n\nWould you like to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->GoldInInventory = TempGold;
		else		
			return 0;
	}

	TempGold = CalculateMaxGold(false);

	if(TempGold != 0)
	{
		if(MessageBox(HWND_DESKTOP, "The program calculated the max gold availible for your character's stash,\nand it determined your character stash gold is greater\nthan the max amount. \n\nWould you like to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->GoldInStash = TempGold;
		else		
			return 0;
	}

	if(RealStats->Strength > MAX_STATS)
	{
		if(MessageBox(HWND_DESKTOP, "The strength value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->Strength = MAX_STATS;
		else
			return 0;
	}

	if(RealStats->Vitality > MAX_STATS)
	{
		if(MessageBox(HWND_DESKTOP, "The vitality value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->Vitality = MAX_STATS;
		else
			return 0;
	}

	if(RealStats->Dexterity > MAX_STATS)
	{
		if(MessageBox(HWND_DESKTOP, "The dexterity value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->Dexterity = MAX_STATS;
		else
			return 0;
	}

	if(RealStats->Energy > MAX_STATS)
	{
		if(MessageBox(HWND_DESKTOP, "The energy value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->Energy = MAX_STATS;
		else
			return 0;
	}

	if(RealStats->StatPoints > MAX_STATS)
	{
		if(MessageBox(HWND_DESKTOP, "The stat points value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->StatPoints = MAX_STATS;
		else
			return 0;
	}

	if(RealStats->SkillPoints > MAX_STATS)
	{
		if(MessageBox(HWND_DESKTOP, "The skill points value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->SkillPoints = MAX_STATS;
		else
			return 0;
	}

	if(RealStats->LifeBase > MAX_CONSTITUTION)
	{
		if(MessageBox(HWND_DESKTOP, "The life base value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->LifeBase = MAX_CONSTITUTION;
		else
			return 0;
	}
	
	if(RealStats->LifeCurrent > MAX_CONSTITUTION)
	{
		if(MessageBox(HWND_DESKTOP, "The life current value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->LifeCurrent = MAX_CONSTITUTION;
		else
			return 0;
	}

	if(RealStats->StaminaBase > MAX_CONSTITUTION)
	{
		if(MessageBox(HWND_DESKTOP, "The stamina base value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->StaminaBase = MAX_CONSTITUTION;
		else
			return 0;
	}

	if(RealStats->StaminaCurrent > MAX_CONSTITUTION)
	{
		if(MessageBox(HWND_DESKTOP, "The stamina current value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->StaminaCurrent = MAX_CONSTITUTION;
		else
			return 0;
	}

	if(RealStats->ManaBase > MAX_CONSTITUTION)
	{
		if(MessageBox(HWND_DESKTOP, "The mana base value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->ManaBase = MAX_CONSTITUTION;
		else
			return 0;
	}

	if(RealStats->ManaCurrent > MAX_CONSTITUTION)
	{
		if(MessageBox(HWND_DESKTOP, "The mana current value loaded in is greater\nthan the max value allowd by the editor!\n\nAttempt to fix?", NAME, MB_YESNO | MB_APPLMODAL | MB_ICONSTOP) == IDYES)
			RealStats->ManaCurrent = MAX_CONSTITUTION;
		else
			return 0;
	}

return 1;
};

int CharacterInformation::CheckCharacterSkills(CharacterSkills &Character)
{
	strcpy(Compare, Character.If);
	
	Compare[2] = '\0';
	
	if(strcmp(Compare, "if") != 0)
	{
		MsgBoxError("The skills header was not found!\nThis is a serious error.\nThe editor can not fix!\n\nExiting now");
		return 0;
	}

return 1;
};

int CharacterInformation::CheckCharacterItems(CharacterItems &Items)
{
	strcpy(Compare, Items.JM);
	
	Compare[2] = '\0';
	
	if(strcmp(Compare, "JM") != 0)
	{
		MsgBoxError("Could not locate the first JM tag!\nThis is a very serious error!\n\nExiting now");
		return 0;
	}

return 1;
}

CharacterHeader CharacterInformation::GetCharacterInfo()
{
	return CharacterInfo;
}

CharacterQuestHeader CharacterInformation::GetCharacterQuestHeader()
{
	return CharacterQuestHead;
}

CharacterQuests *CharacterInformation::GetCharacterQuests()
{
	return CharacterQuest;
}
	
CharacterWayPointHeader CharacterInformation::GetCharacterWayPointHead()
{
	return CharacterWayPointHead;
}

CharacterWayPoints *CharacterInformation::GetCharacterWayPoints()
{
	return CharacterWayPoint;
}
		
CharacterNPC CharacterInformation::GetCharacterNpc()
{
	return CharacterNpc;
}
	
CharacterStats CharacterInformation::GetCharacterStats()
{
	return CharacterStat;
}

CharacterSkills CharacterInformation::GetCharacterSkills()
{
	return CharacterSkill;
}

CharacterItems CharacterInformation::GetCharacterItems()
{
	return Items;
}

long CharacterInformation::SetConstitutionValue(unsigned long Value, int StatNumber, char *Text)
{
	if(strlen(Text) > strlen(MAX_CONSTITUTION_TEXT))
	{
		Stats1[StatNumber] = MAX_CONSTITUTION;
		return MAX_CONSTITUTION;
	}
	
	if(Value > MAX_CONSTITUTION)
	{
		Stats1[StatNumber] = MAX_CONSTITUTION;
		return MAX_CONSTITUTION;
	}
	else
	{
		Stats1[StatNumber] = Value;
		return 0;
	}

return 0;
}

long CharacterInformation::SetStatsValue(unsigned long Value, int StatNumber, bool Over)
{
	if(Over)
		Stats1[StatNumber] = MAX_STATS;
	else
		Stats1[StatNumber] = Value;

return 0;
}
unsigned long CharacterInformation::SetCharacterGold(unsigned long Value, bool StashIfFalse)
{
	if(StashIfFalse)
	{
		unsigned long Gold = CalculateMaxGold1(true);

		if(Value >  999999)
		{
			RealStats->GoldInInventory = Gold;
			return Gold;
		}
	
		if(Gold < Value)
		{
			RealStats->GoldInInventory = Gold;
			return Gold;
		}
		else
		{
			RealStats->GoldInInventory = Value;
			return 0;
		}
	}
	else
	{
		unsigned long Gold = CalculateMaxGold1(false);
		
		if(Value >  9999999)
		{
			RealStats->GoldInStash = Gold;
			return Gold;
		}
	
		if(Gold < Value)
		{
			RealStats->GoldInStash = Gold;
			return Gold;
		}
		else
		{
			RealStats->GoldInStash = Value;
			return 0;
		}
	}

return 0;
}

void CharacterInformation::SetHardcore(int Hardcore, HWND hWnd)
{
	CharacterInfo.HardCore = Hardcore;

	int x = 0;

	if(Hardcore)
	{
		for(x = 0; x<4; x++)
			SetDlgItemText(hWnd, IDC_STATS_TYPE1+x, TypesHardcore[x]);
	}
	else
	{
		for(x = 0; x<4; x++)
			SetDlgItemText(hWnd, IDC_STATS_TYPE1+x, Types[x]);
	}
}
void CharacterInformation::SetDied(int Died)
{
	CharacterInfo.Died = Died;
}
void CharacterInformation::SetClass(int Class)
{
	CharacterInfo.CharacterClass = Class;
}
void CharacterInformation::SetDifficulty(int Difficulty, HWND hWnd)
{
	CharacterInfo.NormalActive = 0;
	CharacterInfo.NightmareActive = 0;
	CharacterInfo.HellActive = 0;
	
	if(Difficulty == 0)	
	{
		CharacterInfo.NormalActive = 1;
		SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.NormalChacterAct, (LPARAM)0);
	}
	else if(Difficulty == 1)
	{
		CharacterInfo.NightmareActive = 1;
		SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.NightmareChacterAct, (LPARAM)0);
	}
	else if(Difficulty == 2)
	{
		CharacterInfo.HellActive = 1;
		SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.HellChacterAct, (LPARAM)0);
	}
	else
	{
		CharacterInfo.NormalActive = 1;
		SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.NightmareChacterAct, (LPARAM)0);
	}
}

void CharacterInformation::SetStartingTown(int Town)
{
	if(CharacterInfo.NormalActive)
		CharacterInfo.NormalChacterAct = Town;
	else if(CharacterInfo.NightmareActive)
		CharacterInfo.NightmareChacterAct = Town;
	else if(CharacterInfo.HellActive)
		CharacterInfo.HellChacterAct = Town;
}

void CharacterInformation::SetCharacterStatus(int Status)
{
	Status -= 1050;

	for(int x = 0; x<4; x++)
	{	
		if(CharacterStatusIds[x].ID == Status)
		{
			CharacterInfo.ChracterProgress = CharacterStatusIds[x].Number;
			break;
		}
	}
}
void CharacterInformation::SetCharacterName(char *Name)
{


}