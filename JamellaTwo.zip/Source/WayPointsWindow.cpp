//Made By Matt H.

#include "WorldWide.h"
#include "Character.h"
#include "CharacterTables.h"

BOOL CALLBACK WayPointsProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch(Msg)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hWnd, IDC_BORDER1, "Unfinished Waypoints");
			SetDlgItemText(hWnd, IDC_BUTTON1, "!Hit me!");
		return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_BUTTON1:
				static bool Test = false;	

				if(Test == false)
				{
					Test = true;
					HWND hTemp;
					hTemp = GetDlgItem(hWnd, IDC_BOX1);
					SendMessage(hTemp, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"A new start?");
				}
				else
				{
					Test = false;
					HWND hTemp;
					hTemp = GetDlgItem(hWnd, IDC_BOX1);
					SendMessage(hTemp, WM_SETTEXT, 0, (LPARAM)(LPCTSTR)"or a end?");
				}
					
					
					
					
			return TRUE;


			}
		return FALSE;

		case WM_NCHITTEST:
			
			/*
			POINT p;

			GetCursorPos(&p);

			RECT rTest;

			GetWindowRect(GetDlgItem(hWnd, IDC_QUESTS_SELECTED1), &rTest);

			if(PtInRect(&rTest, p))
			{
				ShowWindow(GetDlgItem(hWnd, IDC_QUESTS_SELECTED1), true);
				ShowWindow(GetDlgItem(hWnd, IDC_QUESTS_UNSELECTED1), false);
			}
			else
			{
				ShowWindow(GetDlgItem(hWnd, IDC_QUESTS_SELECTED1), false);
				ShowWindow(GetDlgItem(hWnd, IDC_QUESTS_UNSELECTED1), true);
			}
*/
			//make it have a mouse over gre border!

			///make a for loop and go through selected items, mouse can onyl be iun one place at one time!
			//doesnt matter if same id, one id to each dialog! wont ever se e!

			//possible program, cursor going off boundary of message area and kindaselected
			//box doesnt get removed because this MsgProc is never called.
		return TRUE;

		case WM_CLOSE:
		case WM_DESTROY:
			DestroyWindow(hWnd);
		return TRUE;
	}
	return FALSE;
}