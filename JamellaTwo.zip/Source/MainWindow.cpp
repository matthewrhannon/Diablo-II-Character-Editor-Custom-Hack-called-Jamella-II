//Made By Matt H.

#include "WorldWide.h"
#include "Character.h"

HWND Main, Stats, WayPoints, Skills, Quests, Items, Mercenary, Options;
HMENU DebugMenu;

struct 
{
	int ID;
	HWND Window;
}
Windows[] = 
{
	{IDC_MAIN_MAIN, Main},
	{IDC_MAIN_STATS, Stats},
	{IDC_MAIN_SKILLS, Skills},
	{IDC_MAIN_QUESTS, Quests},
	{IDC_MAIN_WAYPOINTS, WayPoints},
	{IDC_MAIN_ITEMS, Items},
	{IDC_MAIN_MERCENARY, Mercenary},
	{IDC_MAIN_OPTIONS, Options},
};

int WindowSize = sizeof(Windows) / sizeof(Windows[0]);

class MainWindow1
{
	public:
		MainWindow1();
		~MainWindow1();

		void Initalize(HWND hWnd);
		
		void LoadResources(HWND hWnd);
		void OpenAgain(HWND hWnd);
		void Moving();

		bool SwitchWindows(HWND hWnd, WPARAM wParam);

	private:
		HWND MainDialog;
};

MainWindow1 MainWindow;

void DestroyWindows()
{
	DestroyWindow(Main);
	DestroyWindow(Stats);
	DestroyWindow(Skills);
	DestroyWindow(Quests);
	DestroyWindow(Items);
	DestroyWindow(WayPoints);
	DestroyWindow(Options);
	DestroyWindow(Mercenary);
}

MainWindow1::MainWindow1()
{
	MainDialog = 0;
	Stats = 0;
	WayPoints = 0;
	Skills = 0;
	Quests = 0;
	Items = 0;
	Mercenary = 0;
	Options = 0;
	Main = 0;
}

MainWindow1::~MainWindow1()
{

}

void MainWindow1::Initalize(HWND hWnd)
{
	SetWindowText(hWnd, NAME);

	for(int x = 0; x<WindowSize; x++)
		EnableWindow(GetDlgItem(hWnd, Windows[x].ID), false);

	EnableWindow(GetDlgItem(hWnd, IDC_MAIN_RELOAD), false);
}
void MainWindow1::LoadResources(HWND hWnd)
{
	for(int x = 0; x<WindowSize; x++)
		EnableWindow(GetDlgItem(hWnd, Windows[x].ID), true);

	Main = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_MAIN1), hWnd, (DLGPROC)WayPointsProc);
	Stats = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_STATS), hWnd, (DLGPROC)StatsProc);
	Quests = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_QUESTS), hWnd, (DLGPROC)QuestsProc);
	Skills = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_SKILLS), hWnd, (DLGPROC)WayPointsProc);
	WayPoints = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_WAYPOINTS), hWnd, (DLGPROC)WayPointsProc);
	Items = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_ITEMS), hWnd, (DLGPROC)WayPointsProc);
	Mercenary = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_MERCENARY), hWnd, (DLGPROC)WayPointsProc);
	Options = CreateDialog(GetWindowInstance(hWnd), MAKEINTRESOURCE(IDD_OPTIONS), hWnd, (DLGPROC)WayPointsProc);

	MainDialog = Main;

	EnableWindow(GetDlgItem(hWnd, IDC_MAIN_MAIN), false);
	ShowWindow(MainDialog, SW_SHOW);

	//This is alright becuase the 150,20 will always be relative to the dialog box because hStats is a child window.
	SetWindowPos(MainDialog, HWND_TOP, 150, 20, 0, 0, SWP_NOSIZE);

	EnableWindow(GetDlgItem(hWnd, IDC_MAIN_RELOAD), true);
}

void MainWindow1::Moving()
{
	SetWindowPos(MainDialog, HWND_TOP, 150, 20, 0, 0, SWP_NOSIZE);
}

bool MainWindow1::SwitchWindows(HWND hWnd, WPARAM wParam)
{
	int x;
	for(x = 0; x<WindowSize; x++)
	{
		if(Windows[x].ID == LOWORD(wParam))
		{
			ShowWindow(MainDialog, false);
			
			switch(Windows[x].ID)
			{
				case IDC_MAIN_MAIN:
					MainDialog = Main;
				break;
				case IDC_MAIN_STATS:
					MainDialog = Stats;
				break;
				case IDC_MAIN_SKILLS:
					MainDialog = Skills;
				break;
				case IDC_MAIN_QUESTS:
					MainDialog = Quests;
				break;
				case IDC_MAIN_ITEMS:
					MainDialog = Items;
				break;
				case IDC_MAIN_MERCENARY:
					MainDialog = Mercenary;
				break;
				case IDC_MAIN_OPTIONS:
					MainDialog = Options;
				break;
				case IDC_MAIN_WAYPOINTS:
					MainDialog = WayPoints;
				break;
			}

			int y;
			for(y = 0; y<WindowSize; y++)
				EnableWindow(GetDlgItem(hWnd, Windows[y].ID), true);

			EnableWindow(GetDlgItem(hWnd, Windows[x].ID), false);

			//EnableWindow(GetDlgItem(hWnd, Windows[x].ID), false);
			SetFocus(GetDlgItem(hWnd, Windows[x].ID));

			ShowWindow(MainDialog, true);
					
			SetWindowPos(MainDialog, HWND_TOP, 150, 20, 0, 0, SWP_NOSIZE);
		}
	}

	return true;
}

void MainWindow1::OpenAgain(HWND hWnd)
{
	DestroyWindow(Main);
	DestroyWindow(Stats);
	DestroyWindow(Skills);
	DestroyWindow(Quests);
	DestroyWindow(Items);
	DestroyWindow(WayPoints);
	DestroyWindow(Options);
	DestroyWindow(Mercenary);

	Initalize(hWnd);
	LoadResources(hWnd);
}

BOOL CALLBACK MainProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	static bool First = true;		
	switch(Msg)
	{

		case WM_INITDIALOG:
			//Draw Icon
			HICON hIcon;

			hIcon = LoadIcon(MainInstance, MAKEINTRESOURCE(IDI_JAM2));
			HDC Window;
			Window = GetDC(hWnd);

			DrawIcon(Window, 0, 0, hIcon);

			DestroyIcon(hIcon);
			
			MainhWnd = hWnd;
			
			MainWindow.Initalize(hWnd);

			SetDlgItemText(hWnd, IDC_MAIN_NAME, "No Character Loaded");
			SetDlgItemText(hWnd, IDC_MAIN_VERSION, VERSION);

			//Load Menu
			if(DEBUG_PROGRAM == 1)
			{
				DebugMenu = LoadMenu(MainInstance, MAKEINTRESOURCE(IDR_MENU3));

				SetMenu(hWnd, DebugMenu);
			}
			else
			{
				DebugMenu = LoadMenu(MainInstance, MAKEINTRESOURCE(IDR_MENU));

				SetMenu(hWnd, DebugMenu);
			}

			//Make up for stupid microsoft not resizing the menu
			RECT rWindow;

			//Right and top are width and height
			GetClientRect(hWnd, &rWindow);

			SetWindowPos(hWnd, NULL, 0, 0, rWindow.right, rWindow.bottom+70, SWP_NOMOVE | SWP_NOACTIVATE);
		return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_MAIN_EXIT:
					PostQuitMessage(0);
				return TRUE;

				case IDR_OPEN:
					HMENU hMenu;

					hMenu = GetMenu(hWnd);
					//Thank you Chris
					EnableMenuItem(hMenu, IDR_SAVE, MF_BYCOMMAND | MF_ENABLED);
					EnableMenuItem(hMenu, IDR_RELOAD, MF_BYCOMMAND | MF_ENABLED);

					DestroyMenu(hMenu);

					int Result;
					Result = FileInfo.LoadCharacter();
					
					if(Result != 0)
						if(First)
						{
							MainWindow.LoadResources(hWnd);
							First = false;
						}
						else
							MainWindow.OpenAgain(hWnd);
					else
					{
						MsgBoxError("The editor was unable to load the specified file!\n\nTo get around these errors,go to options and change the error checking\nto Medium(Checksum, filesize) or None(for anything)");
						return FALSE;
					}

				return TRUE;

				case IDR_SAVE:
					if(FileInfo.SaveCharacter() != 1)
						MsgBoxError("Could not save file!");
				return TRUE;

				case IDC_MAIN_RELOAD:
					if(FileInfo.ReloadCharacter() != 1)
						MsgBoxError("Could not reload the character!");
					else
						MainWindow.OpenAgain(hWnd);
				return TRUE;

				case ID_DEBUG_COMPAREFILES:
					DialogBox(MainInstance, MAKEINTRESOURCE(IDD_DEBUG_COMPARE), HWND_DESKTOP, (DLGPROC)WayPointsProc);
				return TRUE;

				case ID_DEBUG_SEARCHFILE:
					DialogBox(MainInstance, MAKEINTRESOURCE(IDD_DEBUG_SEARCH), HWND_DESKTOP, (DLGPROC)WayPointsProc);
				return TRUE;

				case ID_DEBUG_MAINDEBUG:
					DialogBox(MainInstance, MAKEINTRESOURCE(IDD_DEBUG_MAIN), HWND_DESKTOP, (DLGPROC)WayPointsProc);
				return TRUE;
			}

			//Didnt get processed, must be the controls
			if(MainWindow.SwitchWindows(hWnd, wParam))
				return TRUE;

		return FALSE;

		case WM_MOVING:
			MainWindow.Moving();
		return TRUE;

		case WM_CLOSE:
			DestroyMenu(DebugMenu);
			DestroyWindows();

			PostQuitMessage(0);
		return TRUE;

		case WM_DESTROY:
			DestroyMenu(DebugMenu);
			DestroyWindows();

			PostQuitMessage(0);
		return TRUE;
	}

	return FALSE;
}
