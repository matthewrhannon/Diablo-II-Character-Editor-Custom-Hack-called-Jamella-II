//Made By Matt H.

#include "WorldWide.h"
#include "Character.h"
#include "MiscDataTables.h"

HWND g_Quests;

BOOL CALLBACK QuestsProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch(Msg)
	{
		case WM_INITDIALOG:
			g_Quests = hWnd;
			
			HWND TempTab;

			TempTab = GetDlgItem(hWnd, IDC_QUESTS_TAB);
			
			TCITEM Item;
			memset(&Item, 0, sizeof(Item));

			Item.mask = TCIF_TEXT;
			Item.pszText = "Act 1";

			TabCtrl_InsertItem(TempTab, 0, &Item);

			Item.mask = TCIF_TEXT;
			Item.pszText = "Act 2";

			TabCtrl_InsertItem(TempTab, 1, &Item);

			Item.mask = TCIF_TEXT;
			Item.pszText = "Act 3";

			TabCtrl_InsertItem(TempTab, 2, &Item);

			Item.mask = TCIF_TEXT;
			Item.pszText = "Act 4";

			TabCtrl_InsertItem(TempTab, 3, &Item);

			Item.mask = TCIF_TEXT;
			Item.pszText = "Act 5";

			TabCtrl_InsertItem(TempTab, 4, &Item);

			HWND TestQuest;

			TestQuest = CreateDialog(MainInstance, MAKEINTRESOURCE(IDD_QUESTS_DIALOG1), hWnd, (DLGPROC)WayPointsProc);
			
			RECT Rect;
			GetWindowRect(GetDlgItem(hWnd, IDC_QUESTS_TAB), &Rect);

			POINT Point;

			Point.x = Rect.left;
			Point.y = Rect.top;
			ScreenToClient(hWnd, &Point);

			//+30 to make up for tab buttons
			SetWindowPos(TestQuest, NULL, Point.x, Point.y+30, 0, 0, SWP_NOSIZE);
			ShowWindow(TestQuest, SW_SHOW);
		return TRUE;
		//Destroy the windows each time cel changes to avoid mis upp's withj selected bitmaps........or not.. could always just deselected them

		case WM_NCHITTEST:
			POINT p;

			GetCursorPos(&p);
		return TRUE;

///well the whole cursor thing is fucked up//
		// i was messig with the resource filke to try to fix it
		//if only fucken microsoft could get there fucken shit in order!
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{



			}
		return FALSE;

		case WM_CLOSE:
		case WM_DESTROY:
			DestroyWindow(hWnd);
		return TRUE;
	}
	return FALSE;
}