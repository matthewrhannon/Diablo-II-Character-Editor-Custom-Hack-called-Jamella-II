//Made By Matt H.

#pragma once
#define PLZ 0
#include "WorldWide.h"

//The magic right here. Love it, i sure do..
#pragma pack(1)

struct CharacterHeader
{
	long FileTag;
	long FileVersion;

	long FileSize;
	long FileCheckSum;

	long Unknown01;
	/*
	if(PLZ == 1)
	{
		int Yes;
	}
	*/
	char CharacterName[16];

	//Charcter Bit Fields (I.e Name:Size;)
	//Values that are bitfields are unsigned or they deliever very strange headache results
	
	unsigned char Unknown02:2;
	unsigned char HardCore:1;
	unsigned char Died:1;
	unsigned char Unknown03:1;

	unsigned char Expansion:1;
	unsigned char Unknown04:2;

	char ChracterProgress;

	char Unknown05[2];

	char CharacterClass;
	char Unknown06[2];

	char CharacterLevel;

	long Unknown07;
	long TimeStamp;

	long Unknown08;

	long SkillIds[16]; 
	long LeftMouseId;
	long RightMouseId;

	long AlternativeLeftMouse;
	long AlternativeRightMouse;

	char Unknown09[32];

	//Active is for what difficulty they are on, and act is still filled in even though you arent there.
	unsigned char NormalChacterAct:3;
	unsigned char NormalUnknown10:4;

	unsigned char NormalActive:1;

	unsigned char NightmareChacterAct:3;
	unsigned char NightmareUnknown10:4;

	unsigned char NightmareActive:1;

	unsigned char HellChacterAct:3;
	unsigned char HellUnknown10:4;

	unsigned char HellActive:1;

	long MapID;

	short Unknown11;

	short MercenaryAlive; //NonZero if not Dead, Zero if dead

	long MercenaryID;

	short MercenaryName;
	short MercenaryAttributesActAndAct;

	long MercenaryExperience;

	char Unknown12[144];
};

struct CharacterQuestHeader
{
	char Woo[4];		
	char Unknown[6];
};

struct CharacterQuests
{
	short IntroducedAct1;
	short Act1Quests[6];

	short TravelAct2;
	short IntroducedAct2;
	short Act2Quests[6];

	short TravelAct3;
	short IntroducedAct3;
	short Act3Quests[6];

	short TravelAct4;
	short IntroducedAct4;
	short Act4Quests[3];

	short TravelAct5;
	short Unknown1[3];

	short Unknown2[3];
	short Act5Quests[6];

	short Unknown3[7];
};

struct CharacterWayPointHeader
{
	char WS[2];
	char Unknown[6];
};

struct CharacterWayPoints
{
	char Unknown1[2];
	char WayPoints[5];

	char Unknown2[17];
};

struct CharacterNPC
{
	char Unknown;
	char W4[2];
	char NPCData[49]; //Temp right now, add support for later.
};

struct CharacterStats
{
	char GF[2];
	short StatBits;
};

extern long Stats1[16];

struct RealStats1
{
	long Strength;
	long Energy;
	long Dexterity;
	long Vitality;
	long StatPoints;
	long SkillPoints;
	long LifeCurrent;
	long LifeBase;
	long ManaCurrent;
	long ManaBase;
	long StaminaCurrent;
	long StaminaBase;
	long Level;
	long Experience;
	long GoldInInventory;
	long GoldInStash;
};

extern RealStats1 *RealStats;

struct CharacterSkills
{
	char If[2];
	char Skills[30];
};

struct CharacterItems
{
	char JM[2];
	short AmountItems;
};

//Put structure packing back to normal
#pragma pack()

//Item list here