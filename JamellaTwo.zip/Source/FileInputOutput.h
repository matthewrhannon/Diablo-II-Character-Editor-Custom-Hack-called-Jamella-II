//By Matt H.
//NOTE: I hope you fall off a very tall cliffe.

#pragma once

#include "WorldWide.h"

class CharacterProgression
{
	public:
		CharacterProgression();
		~CharacterProgression(); //Delete memory for data here
		
		char *CreateFileName(bool Open);
		BYTE *GetFileInformation();

		BYTE *ReloadCharacter();

		int WriteFileInformation();

		char *ReturnFilePath();
		char *ReturnFileName();

		DWORD ReturnFileSize();
		DWORD ReturnReadFileSize();

	private:
		char *FilePath;
		char FileName[256];

		DWORD FileSize;
		DWORD FileReadSize;

		BYTE *CharacterData;
};
