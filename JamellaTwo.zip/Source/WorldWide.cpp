//Made By Matt H.

#include "WorldWide.h"
#include "Character.h"

char Buffer[256];
HWND MainhWnd;
CharacterInformation FileInfo;

char *MakeDecimal(int X)
{
	sprintf(Buffer, "%d", X);
	
	return Buffer;
}

void ErrorMessage()
{
	char String[256];
	
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(),0, (LPTSTR)String, 260, NULL);
	MessageBox(HWND_DESKTOP, String, NAME, MB_OK | MB_ICONINFORMATION);
}