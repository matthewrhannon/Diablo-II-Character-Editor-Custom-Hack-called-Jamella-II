//Made By Matt H.

#include "WorldWide.h"
#include "Character.h"
#include "MiscDataTables.h"

CharacterHeader CharacterInfo;

bool CheckName(char *Name)
{
	int Amount = 0;
	int Step = 0;
	int SizeofName = 0;
	
	if(!strlen(Name))
		return false;

	SizeofName = strlen(Name);

	while(*Name)
	{
		if(!isalpha(*Name))
			if(!(strcmp(Name, "-")  || strcmp(Name, "_")) && Step > 0 && Step < SizeofName)
				return false;

		if(strcmp(Name, "-") == 0 || strcmp(Name, "_") == 0)
			Amount++;

		if(Amount > 2)
			return false;

		Name++;
		Step++;
	}

return true;
}

long CalculateMaxGold(bool IfStashFalse)
{
	bool Stash = IfStashFalse;

	if(Stash)
	{
		long CharacterGold = RealStats->Level * 10000;

		if(RealStats->GoldInInventory > CharacterGold)
			return CharacterGold;
	}
	else 
	{
		long CharacterStash;

		if(RealStats->Level <= 30)
			CharacterStash = (RealStats->Level / 10 + 1) * 50000;
		else
			CharacterStash = (RealStats->Level / 2 + 1) * 50000;

		if(RealStats->GoldInStash > CharacterStash)
			return CharacterStash;
	}

return 0;
}

long CalculateMaxGold1(bool IfStashFalse)
{
	bool Stash = IfStashFalse;

	if(Stash)
	{
		long CharacterGold = RealStats->Level * 10000;

		return CharacterGold;
	}
	else 
	{
		long CharacterStash;

		if(RealStats->Level <= 30)
			CharacterStash = (RealStats->Level / 10 + 1) * 50000;
		else
			CharacterStash = (RealStats->Level / 2 + 1) * 50000;

		return CharacterStash;
	}

return 0;
}

//Must be pointers because if not, it will make instance of self that isnt updated when file is loaded..
struct
{
	int ControlID;
	long *Value;
}
Controls[] = 
{
	{IDC_STATS_STRENGTH,		&RealStats->Strength},
	{IDC_STATS_VITALITY,		&RealStats->Vitality},
	{IDC_STATS_DEXTERITY,		&RealStats->Dexterity},
	{IDC_STATS_ENERGY,			&RealStats->Energy},
	{IDC_STATS_MANAREAL,		&RealStats->ManaCurrent},
	{IDC_STATS_MANABASE,		&RealStats->ManaBase},
	{IDC_STATS_LIFEREAL,		&RealStats->LifeCurrent},
	{IDC_STATS_LIFEBASE,		&RealStats->LifeBase},
	{IDC_STATS_STAMINAREAL,		&RealStats->StaminaCurrent},
	{IDC_STATS_STAMINABASE,		&RealStats->StaminaBase},
	{IDC_STATS_GOLDINVENTORY,	&RealStats->GoldInInventory},
	{IDC_STATS_GOLDSTASH,		&RealStats->GoldInStash},
	{IDC_STATS_STATPOINTS,		&RealStats->StatPoints},
	{IDC_STATS_EXPERIENCE,		&RealStats->Experience},
	{IDC_STATS_LEVEL,			&RealStats->Level},
};

int ControlSize = sizeof(Controls) / sizeof(Controls[0]);

BOOL CALLBACK StatsProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	unsigned long Value = 0l;
	bool Over = false;
	char Text[256];
	long lText;

	switch(Msg)
	{
		case WM_INITDIALOG:
			int x;
			for(x = 0; x<7; x++)
				SendDlgItemMessage(hWnd, IDC_STATS_CLASS, CB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)Classes[x]);
			for(x = 0; x<3; x++)
				SendDlgItemMessage(hWnd, IDC_STATS_DIFFICULTY, CB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)Difficultys[x]);
			for(x = 0; x<5; x++)
				SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_ADDSTRING, (WPARAM)0, (LPARAM)(LPCTSTR)StartingTowns[x]);

			CharacterInfo = FileInfo.GetCharacterInfo();

			if(CharacterInfo.HardCore)
			{
				for(x = 0; x<4; x++)
					SetDlgItemText(hWnd, IDC_STATS_TYPE1+x, TypesHardcore[x]);
			}
			else
			{
				for(x = 0; x<4; x++)
					SetDlgItemText(hWnd, IDC_STATS_TYPE1+x, Types[x]);
			}

			for(x = 0; x<ControlSize; x++)
				SetDlgItemInt(hWnd, Controls[x].ControlID, *Controls[x].Value, false);

			//NOTE: Was going to use void * so i could use any type but ran
			//	into a problem with controls using different functions
			//	to do what they need to do.
			
			EnableWindow(GetDlgItem(hWnd, IDC_STATS_EXPANSION), false);
			CheckDlgButton(hWnd, IDC_STATS_EXPANSION, CharacterInfo.Expansion);

			CheckDlgButton(hWnd, IDC_STATS_HARDCORE, CharacterInfo.HardCore);
			CheckDlgButton(hWnd, IDC_STATS_DIED, CharacterInfo.Died);
			
			SetDlgItemText(hWnd, IDC_STATS_NAME, CharacterInfo.CharacterName);
			SendDlgItemMessage(hWnd, IDC_STATS_CLASS, CB_SETCURSEL, (WPARAM)CharacterInfo.CharacterClass, (LPARAM)0);
			
			if(CharacterInfo.NormalActive)
			{
				SendDlgItemMessage(hWnd, IDC_STATS_DIFFICULTY, CB_SETCURSEL, (WPARAM)0, (LPARAM)0);
				SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.NormalChacterAct, (LPARAM)0);
			}
			else if(CharacterInfo.NightmareActive)
			{
				SendDlgItemMessage(hWnd, IDC_STATS_DIFFICULTY, CB_SETCURSEL, (WPARAM)1, (LPARAM)0);
				SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.NightmareChacterAct, (LPARAM)0);
			}
			else if(CharacterInfo.HellActive)
			{
				SendDlgItemMessage(hWnd, IDC_STATS_DIFFICULTY, CB_SETCURSEL, (WPARAM)2, (LPARAM)0);
				SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_SETCURSEL, (WPARAM)CharacterInfo.HellChacterAct, (LPARAM)0);
			}

			if(CharacterInfo.ChracterProgress <= 3)
				CheckDlgButton(hWnd, IDC_STATS_TYPE1, true);
			else if(CharacterInfo.ChracterProgress <= 8)
				CheckDlgButton(hWnd, IDC_STATS_TYPE2, true);
			else if(CharacterInfo.ChracterProgress <= 13)
				CheckDlgButton(hWnd, IDC_STATS_TYPE3, true);
			else if(CharacterInfo.ChracterProgress = 15)
				CheckDlgButton(hWnd, IDC_STATS_TYPE4, true);

			//Set main controls
			SetDlgItemText(MainhWnd, IDC_MAIN_NAME, CharacterInfo.CharacterName);
			SetDlgItemText(MainhWnd, IDC_MAIN_VERSION, VERSION);
			SetDlgItemText(MainhWnd, IDC_MAIN_CHARACTER, "Character Loaded");

		return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_STATS_STRENGTH:
					Over = false;
					
					GetDlgItemText(hWnd, IDC_STATS_STRENGTH, Text, 256);

					lText = atol(Text);

					if(strlen(Text) > 10)
					{
						SetDlgItemText(hWnd, IDC_STATS_STRENGTH, MAX_STATS_TEXT);
						Over = true;
					}

					if(lText > MAX_STATS)
					{
						SetDlgItemText(hWnd, IDC_STATS_STRENGTH, MAX_STATS_TEXT);
						Over = true;
					}

					FileInfo.SetStatsValue(lText, 0, Over);
				return TRUE;

				case IDC_STATS_DEXTERITY:
					Over = false;
					
					GetDlgItemText(hWnd, IDC_STATS_DEXTERITY, Text, 256);

					lText = atol(Text);

					if(strlen(Text) > 10)
					{
						SetDlgItemText(hWnd, IDC_STATS_DEXTERITY, MAX_STATS_TEXT);
						Over = true;
					}

					if(lText > MAX_STATS)
					{
						SetDlgItemText(hWnd, IDC_STATS_DEXTERITY, MAX_STATS_TEXT);
						Over = true;
					}

					FileInfo.SetStatsValue(lText, 2, Over);
				return TRUE;

				case IDC_STATS_VITALITY:
					Over = false;
					
					GetDlgItemText(hWnd, IDC_STATS_VITALITY, Text, 256);

					lText = atol(Text);

					if(strlen(Text) > 10)
					{
						SetDlgItemText(hWnd, IDC_STATS_VITALITY, MAX_STATS_TEXT);
						Over = true;
					}

					if(lText > MAX_STATS)
					{
						SetDlgItemText(hWnd, IDC_STATS_VITALITY, MAX_STATS_TEXT);
						Over = true;
					}

					FileInfo.SetStatsValue(lText, 3, Over);
				return TRUE;

				case IDC_STATS_ENERGY:
					Over = false;
					
					GetDlgItemText(hWnd, IDC_STATS_ENERGY, Text, 256);

					lText = atol(Text);

					if(strlen(Text) > 10)
					{
						SetDlgItemText(hWnd, IDC_STATS_ENERGY, MAX_STATS_TEXT);
						Over = true;
					}

					if(lText > MAX_STATS)
					{
						SetDlgItemText(hWnd, IDC_STATS_ENERGY, MAX_STATS_TEXT);
						Over = true;
					}

					FileInfo.SetStatsValue(lText, 1, Over);
				return TRUE;

				case IDC_STATS_STATPOINTS:
					Over = false;
					
					GetDlgItemText(hWnd, IDC_STATS_STATPOINTS, Text, 256);

					lText = atol(Text);

					if(strlen(Text) > 10)
					{
						SetDlgItemText(hWnd, IDC_STATS_STATPOINTS, MAX_STATS_TEXT);
						Over = true;
					}

					if(lText > MAX_STATS)
					{
						SetDlgItemText(hWnd, IDC_STATS_STATPOINTS, MAX_STATS_TEXT);
						Over = true;
					}

					FileInfo.SetStatsValue(lText, 4, Over);
				return TRUE;

				//Skill points done in another dialog box

				case IDC_STATS_LIFEREAL:
					GetDlgItemText(hWnd, IDC_STATS_LIFEREAL, Buffer, 256);
					
					Value = FileInfo.SetConstitutionValue(GetDlgItemInt(hWnd, IDC_STATS_LIFEREAL, false, false), 6, Buffer);
					
					if(Value != 0)
						SetDlgItemInt(hWnd, IDC_STATS_LIFEREAL, Value, false);
				return TRUE;
				
				case IDC_STATS_LIFEBASE:
					GetDlgItemText(hWnd, IDC_STATS_LIFEBASE, Buffer, 256);
					
					Value = FileInfo.SetConstitutionValue(GetDlgItemInt(hWnd, IDC_STATS_LIFEBASE, false, false), 7, Buffer);
					
					if(Value != 0)
						SetDlgItemInt(hWnd, IDC_STATS_LIFEBASE, Value, false);
				return TRUE;

				case IDC_STATS_MANAREAL:
					GetDlgItemText(hWnd, IDC_STATS_MANAREAL, Buffer, 256);
					
					Value = FileInfo.SetConstitutionValue(GetDlgItemInt(hWnd, IDC_STATS_MANAREAL, false, false), 8, Buffer);
					
					if(Value != 0)
						SetDlgItemInt(hWnd, IDC_STATS_MANAREAL, Value, false);
				return TRUE;

				case IDC_STATS_MANABASE:
					GetDlgItemText(hWnd, IDC_STATS_MANABASE, Buffer, 256);
					
					Value = FileInfo.SetConstitutionValue(GetDlgItemInt(hWnd, IDC_STATS_MANABASE, false, false), 9, Buffer);
					
					if(Value != 0)
						SetDlgItemInt(hWnd, IDC_STATS_MANABASE, Value, false);
				return TRUE;

				case IDC_STATS_STAMINAREAL:
					GetDlgItemText(hWnd, IDC_STATS_STAMINAREAL, Buffer, 256);

					Value = FileInfo.SetConstitutionValue(GetDlgItemInt(hWnd, IDC_STATS_STAMINAREAL, false, false), 10, Buffer);
					
					if(Value != 0)
						SetDlgItemInt(hWnd, IDC_STATS_STAMINAREAL, Value, false);
				return TRUE;

				case IDC_STATS_STAMINABASE:
					GetDlgItemText(hWnd, IDC_STATS_STAMINABASE, Buffer, 256);					
					
					Value = FileInfo.SetConstitutionValue(GetDlgItemInt(hWnd, IDC_STATS_STAMINABASE, false, false), 11, Buffer);
					
					if(Value != 0)
						SetDlgItemInt(hWnd, IDC_STATS_STAMINABASE, Value, false);
				return TRUE;

				case IDC_STATS_STATSMAX:
					int x;
					
					//The control code will make up for the correction from stats to constitution
					for(x = 0; x<ControlSize-5; x++)
						SetDlgItemText(hWnd, Controls[x].ControlID, MAX_STATS_TEXT);
				return TRUE;

				case IDC_STATS_GOLDMAX:
					long Gold;

					Gold = CalculateMaxGold1(true);
					SetDlgItemInt(hWnd, IDC_STATS_GOLDINVENTORY, Gold, false);
					
					Gold = CalculateMaxGold1(false);
					SetDlgItemInt(hWnd, IDC_STATS_GOLDSTASH, Gold, false);
						
				return TRUE;

				case IDC_STATS_RELOAD:
					FileInfo.LoadCharacterData();
				return TRUE;

				/*
				case IDC_STATS_EXPERIENCE:
					if(HIWORD(wParam) == EN_CHANGE)
					{
						long Experience;
						int x;

						GetDlgItemText(hWnd, IDC_STATS_EXPERIENCE, Buffer, 256);

						Experience = atol(Buffer);

						if(strlen(Buffer) > 10)
						{
							Experience = ExperienceLevels[99];
							SetDlgItemInt(hWnd, IDC_STATS_EXPERIENCE, Experience, false);
						}

						if(Experience > ExperienceLevels[99])
						{
							Experience = ExperienceLevels[99];
							SetDlgItemInt(hWnd, IDC_STATS_EXPERIENCE, Experience, false);
						}

						for(x = 0; x<100; x++)
							if(ExperienceLevels[x] > Experience)
							{
								SetDlgItemInt(hWnd, IDC_STATS_LEVEL, x, false);
								break;
							}
						RealStats->Experience = Experience;
						RealStats->Level = x-1;
					}
				return TRUE;
				*/

				case IDC_STATS_LEVEL:
					int Level;

					Level = GetDlgItemInt(hWnd, IDC_STATS_LEVEL, NULL, false);

					if(Level > 99)
					{
						Level = 99;
						SetDlgItemInt(hWnd, IDC_STATS_LEVEL, Level, false);
					}
					else if(Level < 1)
					{
						Level = 1;
						SetDlgItemInt(hWnd, IDC_STATS_LEVEL, Level, false);
					}
					RealStats->Level = Level;
					FileInfo.SetCharacterMainLevel(Level);
		
					RealStats->Experience = ExperienceLevels[RealStats->Level];
	
					SetDlgItemInt(hWnd, IDC_STATS_EXPERIENCE, ExperienceLevels[RealStats->Level], false);
												
					//Set max gold based on level
					long GoldInventory;
				
					Value = GetDlgItemInt(hWnd, IDC_STATS_GOLDINVENTORY, NULL, false);
					
					GoldInventory = FileInfo.SetCharacterGold(Value, true);
	
					if(GoldInventory != 0)
						SetDlgItemInt(hWnd, IDC_STATS_GOLDINVENTORY, GoldInventory, false);

					long GoldStash;

			
					Value = GetDlgItemInt(hWnd, IDC_STATS_GOLDSTASH, NULL, false);

					GoldStash = FileInfo.SetCharacterGold(Value, false);

					if(GoldStash != 0)
						SetDlgItemInt(hWnd, IDC_STATS_GOLDSTASH, GoldStash, false);

				return TRUE;

				case IDC_STATS_DIFFICULTY:
					x = SendDlgItemMessage(hWnd, IDC_STATS_DIFFICULTY, CB_GETCURSEL, 0, 0);

					FileInfo.SetDifficulty(x, hWnd);
				return TRUE;

				case IDC_STATS_CLASS:
					x = SendDlgItemMessage(hWnd, IDC_STATS_CLASS, CB_GETCURSEL, 0, 0);

					FileInfo.SetClass(x);
				return TRUE;

				case IDC_STATS_STARTINGTOWN:
					x = SendDlgItemMessage(hWnd, IDC_STATS_STARTINGTOWN, CB_GETCURSEL, 0, 0);

					FileInfo.SetStartingTown(x);
				return TRUE;

				case IDC_STATS_NAME:
					GetDlgItemText(hWnd, IDC_STATS_NAME, Buffer, 256);

					FileInfo.SetCharacterName(Buffer);
				return TRUE;

				case IDC_STATS_HARDCORE:
					int Hardcore;

					Hardcore = IsDlgButtonChecked(hWnd, IDC_STATS_HARDCORE);

					FileInfo.SetHardcore(Hardcore, hWnd);
				return TRUE;

				case IDC_STATS_DIED:
					int Died;

					Died = IsDlgButtonChecked(hWnd, IDC_STATS_DIED);

					FileInfo.SetDied(Died);
				return TRUE;

				case IDC_STATS_GOLDINVENTORY:
					if(HIWORD(wParam) == EN_CHANGE)
					{
						//Quick Check
						GetDlgItemText(hWnd, IDC_STATS_GOLDINVENTORY, Buffer, 256);

						if(strlen(Buffer) > strlen(MAX_CONSTITUTION_TEXT))
						{
							SetDlgItemInt(hWnd, IDC_STATS_GOLDINVENTORY, MAX_CONSTITUTION, false);
							return TRUE;
						}
						
						Value = GetDlgItemInt(hWnd, IDC_STATS_GOLDINVENTORY, NULL, false);
						
						long GoldInventory;

						GoldInventory = FileInfo.SetCharacterGold(Value, true);
	
						if(GoldInventory != 0)
							SetDlgItemInt(hWnd, IDC_STATS_GOLDINVENTORY, GoldInventory, false);
					}
				return TRUE;

				case IDC_STATS_GOLDSTASH:
					if(HIWORD(wParam) == EN_CHANGE)
					{
						//Quick Check
						GetDlgItemText(hWnd, IDC_STATS_GOLDSTASH, Buffer, 256);

						if(strlen(Buffer) > strlen(MAX_CONSTITUTION_TEXT))
						{
							SetDlgItemInt(hWnd, IDC_STATS_GOLDSTASH, MAX_CONSTITUTION, false);
							return TRUE;
						}
						
						Value = GetDlgItemInt(hWnd, IDC_STATS_GOLDSTASH, NULL, false);
						
						long GoldStash;

						GoldStash = FileInfo.SetCharacterGold(Value, false);

						if(GoldStash != 0)
							SetDlgItemInt(hWnd, IDC_STATS_GOLDSTASH, GoldStash, false);
					}
				return TRUE;

				case IDC_STATS_TYPE1:
				case IDC_STATS_TYPE2:
				case IDC_STATS_TYPE3:
				case IDC_STATS_TYPE4:
					FileInfo.SetCharacterStatus(LOWORD(wParam));
				return TRUE;

			}
		return FALSE;
	}
	return FALSE;
}
