//Win32Base code by Matthew H
#include "WorldWide.h"

HINSTANCE MainInstance;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, char *lpszCmdLine, int nCmdShow)
{
	if(FindWindow(NULL, NAME))
	{
		if(MessageBox(HWND_DESKTOP, "Please Only Run One Instance of this Application at once!\nReason Being:\n   This program uses a substantial amount of system resources\nthat could clog up the system if mutiple copys are run!\n\nExit Now", NAME, MB_YESNO | MB_APPLMODAL) != IDNO)
			return false;
	}
	
	MainInstance = hInstance;
	
	//Initalize Common Controls: Tab, Tree controls
	INITCOMMONCONTROLSEX ControlsStruct;

	memset(&ControlsStruct, 0, sizeof(INITCOMMONCONTROLSEX));
	
	ControlsStruct.dwSize = sizeof(INITCOMMONCONTROLSEX);
	ControlsStruct.dwICC = ICC_TAB_CLASSES;

	if(!InitCommonControlsEx(&ControlsStruct))
	{
		MsgBoxError("Could not initalize the common controls!\nThis is a serious system error.\n\nDownload the necessariy components from microsoft.com to fix!\n\nCan not continue loading program!");
		return false;
	}

	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)MainProc);

	return true;
}

